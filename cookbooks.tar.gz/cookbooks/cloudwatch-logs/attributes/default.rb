default['cwlogs']['region'] = 'us-east-1'
default['cwlogs']['state_file_dir'] = '/var/awslogs/state'
default['cwlogs']['state_file_name'] = 'agent-state'
default['cwlogs']['attempt_upgrade'] = true
