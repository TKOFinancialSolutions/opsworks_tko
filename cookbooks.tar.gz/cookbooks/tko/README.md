# opsworks_tko

http://opsworks-ruby.rzegocki.pl/configuration-builder
http://opsworks-ruby.readthedocs.io/en/latest/getting_started.html

