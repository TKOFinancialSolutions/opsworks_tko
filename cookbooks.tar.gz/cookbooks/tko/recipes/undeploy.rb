# frozen_string_literal: true
#
# Cookbook Name:: tko
# Recipe:: undeploy
#

include_recipe 'opsworks_ruby::undeploy'
