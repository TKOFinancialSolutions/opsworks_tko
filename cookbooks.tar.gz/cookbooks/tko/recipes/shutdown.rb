# frozen_string_literal: true
#
# Cookbook Name:: tko
# Recipe:: shutdown
#

include_recipe 'opsworks_ruby::shutdown'
