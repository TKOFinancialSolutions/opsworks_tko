default['phantomjs']['version'] = 'phantomjs-2.1.1-linux-x86_64'
