# frozen_string_literal: true
#
# Cookbook Name:: opsworks_mspcfo
# Recipe:: setup
#

prepare_recipe

package 'nodejs'
package 'htop'
package 'tmux'
