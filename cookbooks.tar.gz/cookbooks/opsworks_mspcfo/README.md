# opsworks_mspcfo

TODO: Enter the cookbook description here.

# Custom JSON

## Web Layer
```json
{
  "deploy":  {
    "mspcfo": {
      "global": {
        "environment": "staging"
      },
      "database": {
        "adapter": "mysql"
      },
     "framework": {
       "envs_in_console": true,
       "migrate": false
     },
     "appserver": {
       "adapter": "puma",
       "application_yml": true
     }
    }
  }
}
```

## Worker Layer
```json
{
  "deploy": {
    "mspcfo": {
      "global": {
        "environment": "staging"
      },
      "database": {
        "adapter": "mysql",
        "pool": 40
      },
      "framework": {
        "assets_precompile": false,
        "envs_in_console": true,
        "migrate": false
      },
      "appserver": {
        "adapter": "null",
        "application_yml": true
      },
      "worker": {
        "adapter": "sidekiq",
        "config": {
          "concurrency": 15,
          "timeout": 300,
          "queues": [
            "critical",
            "default",
            "paperclip",
            "touch",
            "feed",
            "batch_update",
            "destroyer",
            "extract",
            "calculate"s
          ]
        }
      }
    }
  }
}
```

## Autotask Layer
```json
{
  "deploy": {
    "autotask_scraper": {
      "global": {
        "environment": "staging"
      },
      "database": {
        "adapter": "mysql",
        "pool": 30
      },
      "framework": {
        "assets_precompile": false,
        "envs_in_console": true,
        "migrate": false
      },
      "appserver": {
        "adapter": "null",
        "application_yml": true
      },
      "worker": {
        "adapter": "sidekiq",
        "workers": 1,
        "config": {
          "concurrency": 25,
          "timeout": 300,
          "queues": [
            "critical",
            "default",
            "paperclip",
            "touch",
            "feed",
            "batch_update",
            "destroyer",
            "extract",
            "calculate"
          ]
        }
      }
    }
  }
}
```

## Process Layer
```json
{
  "deploy": {
    "mspcfo": {
      "global": {
        "environment": "staging"
      },
      "database": {
        "adapter": "mysql"
      },
      "framework": {
        "assets_precompile": false
      },
      "appserver": {
        "adapter": "null",
        "application_yml": true
      },
      "webserver": {
        "adapter": "null"
      },
      "whenever": {
        "roles": ["default"]
      }
    },

    "autotask_scraper": {
      "global": {
        "environment": "staging"
      },
      "database": {
        "adapter": "mysql"
      },
      "framework": {
        "assets_precompile": false
      },
      "appserver": {
        "adapter": "null",
        "application_yml": true
      },
      "webserver": {
        "adapter": "null"
      },
      "whenever": {
        "roles": ["default"]
      }
    }
  }
}
```
