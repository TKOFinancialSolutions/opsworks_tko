Author and Contributors
=======================

Author
------

`Igor Rzegocki`_ (`@ajgon`_)

Contributors
------------

* Phong Si (`@phongsi`_)
* Nathan Flood (`@npflood`_)
* Marcos Beirigo (`@marcosbeirigo`_)

.. _Igor Rzegocki: https://www.rzegocki.pl/
.. _@ajgon: https://github.com/ajgon
.. _@phongsi: https://github.com/phongsi
.. _@npflood: https://github.com/npflood
.. _@marcosbeirigo: https://github.com/marcosbeirigo
