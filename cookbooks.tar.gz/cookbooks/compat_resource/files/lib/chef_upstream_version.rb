        module ChefCompat
          CHEF_UPSTREAM_VERSION="12.16.42"
        end
