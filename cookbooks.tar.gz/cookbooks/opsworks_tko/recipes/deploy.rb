# frozen_string_literal: true
#
# Cookbook Name:: tko
# Recipe:: deploy
#

include_recipe 'opsworks_ruby::deploy'